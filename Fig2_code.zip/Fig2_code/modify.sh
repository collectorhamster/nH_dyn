#!/bin/bash

for i in {1..61}; do
    dir="W$i"
    file="$dir/HPC_Lyapunov.jl"
    if [[ -f "$file" ]]; then
    	sed_script=$(cat <<EOF
61s|.*|h=-0.3|
62s|.*|Wi=3.0+0.25*($i-1)|
63s|.*|E=0.0|
64s|.*|Ns=50|
65s|.*|sig=0.0007|
EOF
)
        sed -i "$sed_script" "$file"
    else
    	echo "File not found: $file"
    fi
done
