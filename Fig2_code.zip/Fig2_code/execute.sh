#!/bin/bash

for i in {1..91}; do
	dir="W$i"
	find "$dir" -type f \( -name "*.out" -o -name "*.csv" \) -delete
    (cd "$dir" && sbatch Lyap.slurm)
done
echo "Executtion completed."
