#!/bin/bash

for i in {1..91}; do
    dir="W$i"
    mkdir -p "$dir"
    cp -r upload/* "$dir/"
done