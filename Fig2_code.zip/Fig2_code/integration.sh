#!/bin/bash

mkdir -p data
output1="data/Lyap_complex.csv"
> "$output1"
output2="data/sig_complex.csv"
> "$output2"

for i in {1..91}; do
    fname="W$i/Lyap.csv"
    [[ -f "$fname" ]] && cat "$fname" >> "$output1"
    fname="W$i/sig.csv"
    [[ -f "$fname" ]] && cat "$fname" >> "$output2"
done

echo "Integration completed."
